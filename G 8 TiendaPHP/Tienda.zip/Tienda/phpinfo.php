<?php
	echo phpinfo();
?>